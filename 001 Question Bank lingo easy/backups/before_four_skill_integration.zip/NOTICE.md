# Attribution

Parts of this kit are adapted from or include material from **LuchoBazz/ielts-ai-dataset**
(https://github.com/LuchoBazz/ielts-ai-dataset), licensed under **Creative Commons Attribution 4.0 International (CC BY 4.0)**.

- `config/tts-base-config.json` is an unmodified copy of that repo's `config/tts-config.json` (voice library and delivery presets).
- `.agent/skills/lingoeasy-listening-generator/references/part-type-playbook.md` adapts the structure and conventions of that repo's
  `skills/ielts-listening-generator` (changes: rewritten wording, profile-based distractor rules, multiple-choice conversion).
- `scripts/export_tts_scenario.py` produces configs consumable by that repo's `scripts/generate-tts/` scripts.

Everything else (schema, validator, blueprint, taxonomy, both generator skills, calibration guide, examples) was written for Lingo Easy.
Keep this notice with the kit and in the project's credits if you ship content derived from it.
